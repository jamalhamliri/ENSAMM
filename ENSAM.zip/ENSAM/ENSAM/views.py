from django.http import HttpResponseRedirect


def ent(request):
    return HttpResponseRedirect('https://ent.univh2c.ma/uPortal/f/welcome/normal/render.uP')
